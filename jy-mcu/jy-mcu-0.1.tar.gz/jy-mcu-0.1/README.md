Hardware specification JY-MEGA32 for arduino-ide
